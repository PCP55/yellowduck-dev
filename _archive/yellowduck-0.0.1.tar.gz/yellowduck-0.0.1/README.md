# yellowduck

Data Science Toolbox for everyone

# Can do

- Check duplicate image

# Prerequisites

- os
- hashlib

# Install

```ruby
pip install yellowduck
```

---------------------------------------

This library inspired by 

kora, A collection of tools to make programming on Google Colab easier.

https://github.com/airesearch-in-th/kora/tree/master/kora
